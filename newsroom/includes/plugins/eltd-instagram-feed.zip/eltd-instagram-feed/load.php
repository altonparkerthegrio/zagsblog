<?php

include_once 'lib/eltd-instagram-api.php';
include_once 'widgets/load.php';